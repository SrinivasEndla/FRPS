/**
 * 
 */
function signup(){
	var fname1=document.getElementById("firstname").value;
	window.alert(fname1);
}
